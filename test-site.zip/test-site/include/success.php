<p style="padding: 50px 50px; color: green; font-size: 20px;">Поздравляем! Вы успешно авторизованы!</p>
