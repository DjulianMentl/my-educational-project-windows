<?php

$logins = [
    'admin',
    'adm',
    'Anatoliy',
    'fclm',
    'Geka'
];