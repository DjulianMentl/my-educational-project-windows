<?php

$passwords = [
    'qwerty1',
    'qwerty2',
    'qwerty3',
    'qwerty4',
    'qwerty5'
];