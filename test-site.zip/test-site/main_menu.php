<?php

$menuArray = [
    [
        'title' => 'О компании111111111111111',
        'sort' => 3,
        'path' => '/route/about/'
    ],
    [
        'title' => 'Каталог',
        'sort' => 11,
        'path' => '/route/catalog/'
    ],
    [
        'title' => 'Контакты',
        'sort' => 10,
        'path' => '/route/contacts/'
    ],
    [
        'title' => 'Главная',
        'sort' => 1,
        'path' => '/'
    ],
    [
        'title' => 'Акции',
        'sort' => 8,
        'path' => '/route/actions/'
    ],
    [
        'title' => 'Распродажаffffffffffffffffff',
        'sort' => 2,
        'path' => '/route/sales/'
    ],
    [
        'title' => 'Новинки',
        'sort' => 5,
        'path' => '/route/new/'
    ]
];