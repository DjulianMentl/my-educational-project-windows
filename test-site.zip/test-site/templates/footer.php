
            </td>
        </tr>
    </table>
    
    <?php drawMenu($menuArray, 'main-menu bottom', SORT_DESC); ?>

    <div class="footer">&copy;&nbsp;<nobr>2018</nobr> Project.</div>

</body>
</html>